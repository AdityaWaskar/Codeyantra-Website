import { MongoClient } from "mongodb";
const MONGOURL =
  "mongodb+srv://adityaW:kyOMgKupJshk4WCX@cluster0.tgfwk70.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0/";

const client = new MongoClient(MONGOURL);
const collection = client.db("sales_api").collection("sales");

const salesController = {
  //1-> API to list the all transactions
  async allTransaction(req, res, next) {
    const page = parseInt(req.query.page) || 1;
    const limit = 10;
    const skip = (page - 1) * limit;

    const data = await collection.find().skip(skip).limit(limit).toArray();

    console.log(data);
    res.json(data);
  },

  async statistics(req, res, next) {
    const month = parseInt(req.query.month);

    const data = await collection
      .aggregate([
        {
          $match: {
            $expr: {
              $eq: [
                { $month: { $dateFromString: { dateString: "$dateOfSale" } } },
                month,
              ],
            },
          },
        },
        {
          $facet: {
            totalAmount: [
              {
                $group: {
                  _id: null,
                  totalAmount: {
                    $sum: "$price",
                  },
                },
              },
            ],
            soldStatus: [
              {
                $group: {
                  _id: "$sold",
                  count: { $sum: 1 },
                },
              },
            ],
          },
        },
      ])
      .toArray();
    console.log(data);

    let totalSold, totalNotSold;
    if (data[0].soldStatus[0]._id === true) {
      totalSold = data[0].soldStatus[0].count;
      totalNotSold = data[0].soldStatus[1].count;
    }
    if (data[0].soldStatus[0]._id === false) {
      totalNotSold = data[0].soldStatus[0].count;
      totalSold = data[0].soldStatus[1].count;
    }
    res.json({
      totalAmount:
        data[0].totalAmount.length > 0 ? data[0].totalAmount[0].totalAmount : 0,
      totalSold: totalSold,
      totalNotSold: totalNotSold,
    });
  },

  async barchartData(req, res, next) {
    try {
      const month = parseInt(req.query.month, 10);
      if (isNaN(month) || month < 1 || month > 12) {
        return res.status(400).send("Invalid month parameter");
      }
      const data = await collection
        .aggregate([
          {
            $match: {
              $expr: {
                $eq: [
                  {
                    $month: { $dateFromString: { dateString: "$dateOfSale" } },
                  },
                  month,
                ],
              },
            },
          },
        ])
        .toArray();
      let chartData = {
        "0-100": 0,
        "101-200": 0,
        "201-300": 0,
        "301-400": 0,
        "301-500": 0,
        "301-600": 0,
        "301-700": 0,
        "301-800": 0,
        "801-900": 0,
        "900+": 0,
      };

      data.map((d) => {
        if (withInPrice(d.price, 0, 100)) chartData["0-100"]++;
        else if (withInPrice(d.price, 101, 200)) chartData["101-200"]++;
        else if (withInPrice(d.price, 201, 300)) chartData["201-300"]++;
        else if (withInPrice(d.price, 301, 400)) chartData["301-400"]++;
        else if (withInPrice(d.price, 401, 500)) chartData["301-500"]++;
        else if (withInPrice(d.price, 501, 600)) chartData["301-600"]++;
        else if (withInPrice(d.price, 601, 700)) chartData["301-700"]++;
        else if (withInPrice(d.price, 701, 800)) chartData["301-800"]++;
        else if (withInPrice(d.price, 801, 900)) chartData["801-900"]++;
        else chartData["900+"]++;
      });

      res.json(chartData);
    } catch (error) {
      console.error(error);
      res.status(500).send("Internal Server Error");
    }
  },

  async piechartData(req, res, next) {
    try {
      const month = parseInt(req.query.month, 10);
      if (isNaN(month) || month < 1 || month > 12) {
        return res.status(400).send("Invalid month parameter");
      } // Replace with your DB and collection name

      const data = await collection
        .aggregate([
          {
            $match: {
              $expr: {
                $eq: [
                  {
                    $month: { $dateFromString: { dateString: "$dateOfSale" } },
                  },
                  month,
                ],
              },
            },
          },
        ])
        .toArray();
      let pieData = {};
      data.map((d) => {
        pieData[d.category] = (pieData[d.category] ?? 0) + 1;
      });

      res.json(pieData);
    } catch (error) {
      console.error(error);
      res.status(500).send("Internal Server Error");
    }
  },

  getMonth(dateString) {
    const date = new Date(dateString);
    const month = date.getMonth() + 1;
    console.log(month);
  },
};

const withInPrice = (price, low, high) => {
  if (price >= low && price <= high) return true;
  return false;
};
export default salesController;
