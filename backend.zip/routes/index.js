import express from "express";
const router = express.Router();
import salesController from "../controller/salescontroller.js";

router.get("/getSales", salesController.allTransaction);
router.get("/getStatistics", salesController.statistics);
router.get("/barchartdata", salesController.barchartData);
router.get("/piechartdata", salesController.piechartData);

export default router;
